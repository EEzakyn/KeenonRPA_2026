import ActivityLogs from '../models/activityLogsModel';
import { Op } from 'sequelize';

export const getMeasurementLogs = async (startDate: Date, endDate: Date) => {
    try {
      const logs = await ActivityLogs.findAll({
        where: {
          log_timestamp: {
            [Op.between]: [startDate, endDate],
          },
        },
        order: [['log_timestamp', 'DESC']],
      });
      return logs;
    } catch (error) {
      console.error("🔥 Error inside getMeasssurementLogs:", error);
      throw new Error(`Error fetching activity logs: ${(error as Error).message}`);
    }
  };
  

export const getAllActivityLogs = async () => {
    try {
        const logs = await ActivityLogs.findAll({
            order: [['log_timestamp', 'DESC']],
        });
        return logs;
    } catch (error) {
        throw new Error(`Error fetching activity logs: ${(error as Error).message}`);
    }
}