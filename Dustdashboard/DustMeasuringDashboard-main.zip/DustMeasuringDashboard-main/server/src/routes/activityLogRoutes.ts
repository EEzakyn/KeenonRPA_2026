import express from "express";
import { getActivityLogsHandler } from "../controllers/activityLogController";

const router = express.Router();

router.get('/show-log', getActivityLogsHandler);

export default router;