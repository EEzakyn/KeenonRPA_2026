import { getMeasurementLogs } from "../services/activityLogService";
import { Request, Response } from 'express';

export const getActivityLogsHandler = async (req: Request, res: Response) => {
    try {
        const { startDate, endDate } = req.query;

        if (!startDate || !endDate) {
            res.status(400).json({ message: "Missing required query parameters: startDate, endDate" });
            return;
        }

        // Parse the dates and ensure they are in UTC
        const parsedStartDate = new Date(`${startDate}Z`);
        const parsedEndDate = new Date(`${endDate}Z`);

        if (isNaN(parsedStartDate.getTime()) || isNaN(parsedEndDate.getTime())) {
            res.status(400).json({ message: "Invalid date format. Please use ISO format like 2024-04-10T00:00:00" });
            return;
        }

        // Fetch the logs, now the dates are in UTC format
        const logs = await getMeasurementLogs(parsedStartDate, parsedEndDate);
        res.json(logs);
    } catch (error) {
        console.error("Error in getActivityLogsHandler:", error);
        res.status(500).json({ message: `Error fetching activity logs: ${(error as Error).message}` });
    }
};
