import sequelize from "../database";
import { DataTypes, Model } from "sequelize";

interface activityLogsAttributes {
    id: number;
    log_timestamp: Date;
    location_name: string;
    activity: string;
}

class ActivityLogs extends Model<activityLogsAttributes> implements activityLogsAttributes {
    public id!: number;
    public log_timestamp!: Date;
    public location_name!: string;
    public activity!: string;
}

ActivityLogs.init(
    {
        id: {
            type: DataTypes.INTEGER,
            autoIncrement: true,
            primaryKey: true,
        },
        log_timestamp: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        location_name: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
        activity: {
            type: DataTypes.STRING(255),
            allowNull: false,
        },
    },
    {
        sequelize,
        modelName: "ActivityLogs",
        tableName: "ActivityLogs",
        timestamps: false,
    }
);

export default ActivityLogs;